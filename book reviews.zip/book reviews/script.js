function rateBook(button, ratingType) {
    const parentDiv = button.parentElement;
    const likeButton = parentDiv.querySelector('.like-button');
    const dislikeButton = parentDiv.querySelector('.dislike-button');
    
    if (ratingType === 'like') {
        likeButton.style.backgroundColor = '#4CAF50';
        dislikeButton.style.backgroundColor = '#ccc';
    } else {
        likeButton.style.backgroundColor = '#ccc';
        dislikeButton.style.backgroundColor = '#f44336';
    }
}
function likeBook(bookId) {
    alert('Вы поставили лайк книге ' + bookId);
}

function dislikeBook(bookId) {
    alert('Вы поставили дизлайк книге ' + bookId);
}
  function rateBook(isLiked) {
    if (isLiked) {
        console.log('Книга понравилась');
    } else {
        console.log('Книга не понравилась');
    }
}